// Paths are rewritten only in the GitHub Pages build; visual content is untouched.
export function installPagesApi(){
 if(import.meta.env['VITE_HOSTING_TARGET']!=='github-pages')return;
 const request=window.fetch.bind(window);
 const base=import.meta.env.BASE_URL;
 const feeds=new Set(['challenges','weekly','nazar','news','server-status','translation-status','live-feed','health','admin/session']);
 window.fetch=async(input,init)=>{
  const url=typeof input==='string'?input:input instanceof URL?input.href:input.url;
  const method=init?.method||(input instanceof Request?input.method:'GET');
  const target=new URL(url,location.href);
  if(target.origin!==location.origin||!target.pathname.startsWith('/api/'))return request(input,init);
  const name=target.pathname.slice(5);
  if(method.toUpperCase()!=='GET'||!feeds.has(name))return new Response(JSON.stringify({error:'هذه العملية تحتاج خدمة إدارة خلفية؛ ملفات الموقع الأصلية محفوظة.'}),{status:503,headers:{'Content-Type':'application/json; charset=utf-8'}});
  const response=await request(base+'api/'+name+'.json',{...init,cache:'no-cache'});
  if(!response.ok)return response;
  const value=await response.json();
  const now=Date.now();
  if(name==='challenges'||name==='weekly')value.stale=!value.data||now>=(value.data.endTime+1)*1000;
  if(name==='nazar'){
   value.stale=!value.data||value.data.date!==new Date(now-6*3600000).toISOString().slice(0,10);
   if(value.data?.image?.startsWith('/api/nazar/image/'))value.data.image=base+value.data.image.slice(1);
  }
  if(name==='news'){
   value.stale=!value.lastSuccess||!!value.error||now-Date.parse(value.lastSuccess)>3600000;
   const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
   const part=(type:string)=>today.find(p=>p.type===type)?.value||'';
   const date=`${part('year')}-${part('month')}-${part('day')}`;
   value.items=value.items.filter((item:{expiresAt?:string})=>!/^\d{4}-\d{2}-\d{2}$/.test(item.expiresAt||'')||item.expiresAt!>=date);
   for(const item of value.items)if(item.image?.startsWith('/'))item.image=base+item.image.slice(1);
  }
  if(name==='server-status')value.stale=!value.data||!value.lastSuccess||now-Date.parse(value.lastSuccess)>180000||now-Date.parse(value.data.sourceAsOf)>600000;
  return new Response(JSON.stringify(value),{status:200,headers:{'Content-Type':'application/json; charset=utf-8'}});
 };
}
