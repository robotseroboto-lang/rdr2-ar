// Restored from the preserved original compiled frontend.
import data from './ability-cards-data.json';
export type CardCategory='deadeye'|'combat'|'recovery'|'defense';
export type PlayStyle='solo'|'team'|'pve'|'pvp'|'horse'|'close'|'long'|'tank';
export type AbilityCard={name:string;image?:string;arabic:string;category:CardCategory;kind:string;unlock:number;description:string;pros:string[];cons:string[];styles:PlayStyle[];suited?:string;note?:string};
export const abilityCards=data.abilityCards as AbilityCard[];
export const cardCategories=data.cardCategories as {id:CardCategory;label:string;art:string;description:string}[];
export const playStyles=data.playStyles as {id:PlayStyle;label:string}[];
export const abilityIntro=data.abilityIntro;
