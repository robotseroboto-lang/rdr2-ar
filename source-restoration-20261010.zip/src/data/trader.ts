// Restored production formula from the preserved original roles bundle.
export function traderEstimate(goods:number,target:number,supplies:number){const remaining=Math.max(0,target-goods),minutes=remaining*2;return {remaining,minutes,materials:remaining*2,nextSupply:Math.min(minutes,supplies),resupplies:Math.max(0,Math.ceil((minutes-supplies)/50))};}
export function traderDuration(minutes:number){if(minutes===0)return 'جاهزة الآن';const hours=Math.floor(minutes/60),rest=minutes%60;return [hours?hours+' ساعة':null,rest?rest+' دقيقة':null].filter(Boolean).join(' و');}
